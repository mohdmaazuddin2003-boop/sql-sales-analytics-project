# 📊 Sales Analytics SQL Project

## 🔹 Overview
This project is a Sales Analytics System built using SQL Server.
It uses a star schema with fact and dimension tables to analyze business data.

## 🧱 Database Design
- Customers (Dimension)
- Products (Dimension)
- Dates (Dimension)
- Sales (Fact Table)

## 🚀 Features
- Monthly revenue analysis
- Top selling product categories
- Customer spending insights
- Yearly revenue trends
- Sales summary view for reporting

## 🛠️ Tools Used
- SQL Server (SSMS)
- Excel (for reporting)

## 📊 Key SQL Concepts
- Joins (INNER JOIN)
- Aggregations (SUM, GROUP BY)
- Views
- Star Schema Design

## 💼 Business Use Case
This system helps businesses:
- Track sales performance
- Identify top customers
- Analyze product demand
- Make data-driven decisions

## ✅ Outcome
Developed a real-world SQL project demonstrating strong database design and data analysis skills.
